Simple Json SSIS import Example

1) Deploy Database Objects
2) Change the Root directory in SSIS parameter paramJsonRoot to where you have extracted the Inbound and archive folders. 
3) Change database connection to where you have deployed the database objects. 