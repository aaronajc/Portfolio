USE [Your Database Name Here]
GO 
CREATE SCHEMA [StagingJson]